export const baseUrl = `http://localhost:3001/api/`;

export default { baseUrl };
