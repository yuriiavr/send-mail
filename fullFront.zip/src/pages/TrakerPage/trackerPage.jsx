import SideBar from "../../components/SideBar/sideBar"
import Track from "../../components/Track/track"

const TrackerPage = () => {

    return(
        <>
            <SideBar />
            <Track />
        </>
    )
}

export default TrackerPage;