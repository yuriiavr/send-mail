import Form from "../../components/Form/form";
import SideBar from "../../components/SideBar/sideBar";

const Sender = () => {
    
    return(
        <>
            <SideBar />
            <Form />
        </>
    )
}

export default Sender;